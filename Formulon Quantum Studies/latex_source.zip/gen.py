import pandas as pd, numpy as np, json, re
U='/mnt/user-data/uploads/'; F='/home/claude/fig/'
s=pd.read_csv(U+'summary_by_degree_and_shots.csv'); d=pd.read_csv(U+'deterministic_formulon_vs_scipy.csv'); r=pd.read_csv(U+'formulon_raw_results.csv')
th=pd.read_csv(F+'theory.csv'); cr=pd.read_csv(F+'crlb.csv'); sg=pd.read_csv(F+'sigma.csv',index_col=0).iloc[:,0]
md=json.load(open(U+'benchmark_metadata.json'))
DOI="10.5281/zenodo.23753750"; DATE="29 October 2026"; ORCID="0009-0005-6360-2345"
def esc(x): return str(x).replace('\\','\\textbackslash{}').replace('_','\\_').replace('&','\\&').replace('%','\\%').replace('#','\\#')
def sci(v):
    if v==0: return '0'
    m,e=f"{v:.2e}".split('e'); return f"${m}\\times10^{{{int(e)}}}$"
n_calls=r.drop_duplicates(['x','degree','shots','repetition']).shape[0]
dmax=d.absolute_difference.max(); dmean=d.absolute_difference.mean(); nzero=int((d.absolute_difference==0).sum()); nd=len(d)
q1k=r[(r.shots==1000)&(r.polynomial_order>0)].groupby(['degree','polynomial_order']).squared_feature_error.mean().apply(np.sqrt)
q5=r[(r.shots==5000)&(r.polynomial_order>0)].groupby(['degree','polynomial_order']).squared_feature_error.mean().apply(np.sqrt)
T={}
T['DMAX']=sci(dmax); T['DMEAN']=sci(dmean); T['NZERO']=f"{nzero:,}".replace(',','{,}'); T['ND']=f"{nd:,}".replace(',','{,}'); T['NZEROPCT']=f"{nzero/nd*100:.1f}"
T['NCALLS']=f"{n_calls:,}".replace(',','{,}'); T['NREC']=f"{len(r):,}".replace(',','{,}')
T['THMIN']=f"{(th.ratio.min()-1)*100:+.0f}".replace('-','$-$'); T['THMAX']=f"{(th.ratio.max()-1)*100:+.0f}"
T['THMEAN']=f"{th.ratio.mean():.3f}"; T['THSD']=f"{th.ratio.std():.3f}"; T['THLO']=f"{th.ratio.min():.3f}"; T['THHI']=f"{th.ratio.max():.3f}"
T['CRMEAN']=f"{cr.ratio.mean():.3f}"; T['CRLO']=f"{cr.ratio.min():.3f}"; T['CRHI']=f"{cr.ratio.max():.3f}"
for k in [2,4,6,8,12]: T[f'SG{k}']=f"{sg[k]:.3f}"
T['LO']=f"{q1k.min():.3f}"; T['HI']=f"{q1k.max():.3f}"; T['LO5']=f"{q5.min():.4f}"; T['HI5']=f"{q5.max():.4f}"
# summary table
rows=[]
for _,q in s.iterrows():
    rows.append(f"{int(q.degree)} & {int(q.shots)} & {q.feature_mae:.4f} & {q.feature_rmse:.4f} & {q.feature_max_absolute_error:.4f} & ${q.feature_bias:+.4f}$ & {q.decoded_x_mae:.4f} & {q.decoded_x_rmse:.4f} & {q.decoded_x_max_absolute_error:.4f} \\\\".replace('$+','$+').replace('$-','$-'))
    if int(q.shots)==5000 and int(q.degree)!=12: rows.append("\\addlinespace")
T['SUMTAB']="\n".join(rows)
det=[]
for k in [2,4,6,8,12]:
    v=d[d.requested_degree==k].absolute_difference.max(); c=(d.requested_degree==k).sum()
    det.append(f"{k} & {'0 (exact)' if v==0 else sci(v)} & {c:,} \\\\".replace(',','{,}',1) if False else f"{k} & {'0 (exact)' if v==0 else sci(v)} & {c} \\\\")
T['DETTAB']="\n".join(det)
rt=[]
for dg in [2,4,6,8,12]:
    rt.append(f"{dg} & "+" & ".join(f"{th[(th.degree==dg)&(th.shots==n)].ratio.iloc[0]:.3f}" for n in [100,500,1000,5000])+" \\\\")
T['RATIOTAB']="\n".join(rt)
ct=[]
for _,q in cr.iterrows():
    if int(q.shots) in (100,1000,5000): ct.append(f"{int(q.degree)} & {int(q.shots)} & {q.emp:.5f} & {q.crlb:.5f} & {q.ratio:.3f} \\\\")
T['CRTAB']="\n".join(ct)
bt=[]
for dg in [2,4,6,8,12]: bt.append(f"{dg} & {sg[dg]:.3f} & "+" & ".join(f"{(sg[dg]/t)**2:,.0f}".replace(',','{,}') for t in [0.05,0.02,0.01,0.005])+" \\\\")
T['BUDTAB']="\n".join(bt)
pv=r[r.shots==5000].groupby(['degree','polynomial_order']).squared_feature_error.mean().apply(np.sqrt).unstack()
ap=[]
for dg in pv.index: ap.append(f"{int(dg)} & "+" & ".join("" if np.isnan(v) else f"{v:.4f}" for v in pv.loc[dg].values)+" \\\\")
T['PERORDTAB']="\n".join(ap)
keys=['formulon_version','python_version','platform','numpy_version','pandas_version','scipy_version','pennylane_version','quantum_backend_used_by_formulon','x_points','degrees','shot_levels','repetitions','seed_base']
mrows=[]
for k in keys:
    v=md[k]; v=str(v).split('\n')[0]
    if k=='python_version': v=v.split(' (')[0]+' (Colab)'
    if isinstance(md[k],list): v=', '.join(map(str,md[k]))
    mrows.append(f"\\texttt{{{esc(k.replace('quantum_backend_used_by_formulon','backend'))}}} & {esc(v)} \\\\")
T['METATAB']="\n".join(mrows)
tr=r.drop_duplicates(['x','degree','shots','repetition'])
sl=[]
for dg in [2,4,6,8,12]:
    p=s[s.degree==dg]; a=np.polyfit(np.log(p.shots),np.log(p.feature_rmse),1)[0]; b=np.polyfit(np.log(p.shots),np.log(p.decoded_x_rmse),1)[0]
    sl.append(f"{dg} & ${a:.3f}$ & ${b:.3f}$ & {sg[dg]:.3f} \\\\".replace('$-','$-'))
T['SLOPETAB']="\n".join(sl)
vc=tr.seed.value_counts(); T['NSEEDU']=f"{tr.seed.nunique():,}".replace(',','{,}'); T['NSHARED']=f"{int((tr.seed.map(vc)>1).sum()):,}".replace(',','{,}'); T['NSEEDLVL']=f"{tr.groupby('shots').seed.nunique().iloc[0]:,}".replace(',','{,}')
bi=pd.read_csv(F+'bias.csv')
T['BIASTAB']="\n".join(f"{int(q.degree)} & {int(q.shots)} & {int(q['count'])} & ${q['mean']:+.5f}$ & {q.se:.5f} & ${q.z:+.2f}$ \\\\" for _,q in bi.iterrows())
T['CRFULL']="\n".join(f"{int(q.degree)} & {int(q.shots)} & {q.emp:.5f} & {q.crlb:.5f} & {q.ratio:.3f} \\\\" for _,q in cr.iterrows())
tex=open('template.tex').read()
for k,v in T.items(): tex=tex.replace('@@'+k+'@@',v)
assert '@@' not in tex, re.findall(r'@@\w+@@',tex)
open('report.tex','w').write(tex)
print({k:T[k] for k in ['DMAX','THMIN','THMAX','LO','HI']})
